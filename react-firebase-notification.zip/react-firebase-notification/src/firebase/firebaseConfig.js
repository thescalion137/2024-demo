import { initializeApp } from "firebase/app";

import { getMessaging } from "firebase/messaging";

//Firebase Config values imported from .env file
const firebaseConfig = {
  apiKey: "AIzaSyBY4Fd8Dv1voZnjtAsvhMKUeN141UkCFVE",
  authDomain: "react-notification-9b2c0.firebaseapp.com",
  projectId: "react-notification-9b2c0",
  storageBucket: "react-notification-9b2c0.appspot.com",
  messagingSenderId: "64074231215",
  appId: "1:64074231215:web:7dda56d582019a559e535a",
  measurementId: "G-LS2JSMPK2K",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Messaging service
export const messaging = getMessaging(app);
