import { useMemo } from 'react';
import { StyleSheet } from 'react-native';

import { useResponsiveScreen } from './useResponsiveScreen';
import { normalizeFont } from './normalize';

export const diamondResultStyle = () => {
  const { wp, hp } = useResponsiveScreen();

  const colors = {
    primary: '#024638',
    secondary: '#EFEDF2',
    dimPrimary: '#0246384d',
    dimSecondary: '#AFC9AB4d',
    danger: '#DC3545',
    text: '#555555',
    subText: '#A0A2B3',
    lightText: '#55555555',
    background: '#FFFFFF',
    drawerText: '#FFFFFF',
    headerTitle: '#1C3E71CC',
    lightBackground: '#F6F6F6',
    lightBorder: '#A0A2B333',
    midPrimary: '#02463880',
    disable: '#A0A2B340',
    black: '#000000',
    lowPrimary: '#0246381A',
    active: '#00FF00',
    loader: '#00000080',
    pending: '#fcc201',
  };

  const styles = useMemo(() => {
    return StyleSheet.create({
      container: {
        flex: 1,
        backgroundColor: colors.background,
      },
      cardContentContainer: {
        paddingBottom: hp(15),
      },
      cardView: {
        backgroundColor: colors.background,
        borderTopWidth: 1,
        borderColor: colors.primary,
        alignSelf: 'center',
        width: wp(100),
        overflow: 'hidden',
        flexDirection: 'row',
      },
      pressableCardContainer: {
        flexDirection: 'row',
      },
      cardViewSpace: {
        paddingHorizontal: wp(2),
      },
      selectedItem: {
        backgroundColor: colors.lowPrimary,
      },
      imageContainer: {
        height: wp(26),
        width: wp(28),
        alignSelf: 'center',
        justifyContent: 'center',
      },
      image: {
        height: wp(26),
        width: wp(28),
      },
      availableContainer: {
        width: wp(3),
        alignItems: 'center',
        justifyContent: 'center',
      },
      available: {
        height: wp(5),
        width: wp(1.3),
        marginLeft: wp(-1.3),
      },
      availableColor: {
        backgroundColor: colors.active,
      },
      unAvailableColor: {
        backgroundColor: colors.danger,
      },
      detailedTitle: {
        fontSize: normalizeFont(8),
        textAlign: 'center',
        marginBottom: hp(1.5),
      },
      detailedTitle1: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        // width: wp(11.1),
        color: colors.background,
      },
      detailedText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
      },
      topDetailedText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(5),
        marginBottom: hp(1.5),
      },
      // -- shape
      shapeHeader: {
        width: wp(7),
      },
      shapeBigHeader: {
        width: wp(8),
      },
      shapeText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(7),
        // marginBottom: hp(1.5),
      },
      shapeBigText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(8),
        // marginBottom: hp(1.5),
      },
      // ---

      // -- rate
      rateHeader: {
        width: wp(8),
      },
      rateBigHeader: {
        width: wp(9),
      },
      rateText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(8),
        // marginBottom: hp(1.5),
      },
      rateBigText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(9),
        // marginBottom: hp(1.5),
      },
      // ---
      // -- Price

      totalPriceHeader: {
        width: wp(11),
      },
      totalPriceBigHeader: {
        width: wp(12),
      },
      totalPriceText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(11),
        // marginBottom: hp(1.5),
      },
      totalPriceBigText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(12),
        // marginBottom: hp(1.5),
      },

      // ---

      // -- carat
      caratHeader: {
        width: wp(11),
      },
      caratBigHeader: {
        width: wp(12),
      },
      caratText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(11),
        // marginBottom: hp(1.5),
      },
      caratBigText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(12),
        // marginBottom: hp(1.5),
      },
      // ---

      // -- color

      colorHeader: {
        width: wp(8),
      },
      colorBigHeader: {
        width: wp(9),
      },
      colorText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(8),
        // marginBottom: hp(1.5),
      },
      colorBigText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(9),
        // marginBottom: hp(1.5),
      },

      // ---

      // -- clarity

      clarityHeader: {
        width: wp(9),
      },
      clarityBigHeader: {
        width: wp(10),
      },
      clarityText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(9),
        // marginBottom: hp(1.5),
      },
      clarityBigText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(10),
        // marginBottom: hp(1.5),
      },

      // ---

      // -- cut
      cutHeader: {
        width: wp(10),
      },
      cutBigHeader: {
        width: wp(11),
      },
      cutText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(10),
        // marginBottom: hp(1.5),
      },
      cutBigText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(11),
        // marginBottom: hp(1.5),
      },

      // ---

      // -- disc
      discHeader: {
        width: wp(8),
      },
      discBigHeader: {
        width: wp(9),
      },
      discText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(8),
        // marginBottom: hp(1.5),
      },
      discBigText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(9),
        // marginBottom: hp(1.5),
      },

      // ---

      // -- SYM

      symHeader: {
        width: wp(9),
      },
      symBigHeader: {
        width: wp(10),
      },
      symText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(9),
        // marginBottom: hp(1.5),
      },
      symBigText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(10),
        // marginBottom: hp(1.5),
      },

      // ---

      // -- Ratio

      ratioHeader: {
        width: wp(8),
      },
      ratioText: {
        fontSize: normalizeFont(11),
        textAlign: 'center',
        width: wp(8),
        // marginBottom: hp(1.5),
      },

      // ---
      detailsContainer: {
        width: wp(80),
        flexDirection: 'row',
      },
      detailsData: {
        width: '100%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignSelf: 'center',
        // marginTop: hp(1),
      },
      listColumn: {
        flexDirection: 'row',
        paddingTop : hp(1),
        paddingBottom: hp(1)
        // flexGrow: 1,
      },
      listHeader: {
        flexDirection: 'row',
        // marginTop: hp(2),
        // marginHorizontal: wp(2),
        backgroundColor: colors.primary,
        color: colors.background,
        // paddingHorizontal: wp(2),
        paddingVertical: hp(1),
        // textAlignVertical: 'center',
      },
      checkboxContainer: {
        width: wp(8),
        alignItems: 'flex-end',
        justifyContent: 'center',
        zIndex: 10,
      },
      floatingButton: {
        height: wp(18),
        width: wp(18),
        borderRadius: 50,
        backgroundColor: colors.secondary,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        bottom: hp(2),
        right: wp(2),
        zIndex: 9999,
      },
      subFloatingButton: {
        height: wp(14),
        width: wp(14),
        borderRadius: 50,
        backgroundColor: colors.secondary,
        alignItems: 'center',
        justifyContent: 'center',
        elevation: 2,
        shadowOffset: {
          width: 0,
          height: 1,
        },
        shadowOpacity: 0.16,
        shadowRadius: 1.51,
      },
      subButtonContainer: {
        flexDirection: 'row',
        position: 'absolute',
        alignItems: 'center',
        justifyContent: 'center',
        right: wp(4),
      },
      subButtonTitle: {
        backgroundColor: colors.background,
        marginRight: wp(2),
        paddingHorizontal: wp(1),
        elevation: 2,
        shadowOffset: {
          width: 0,
          height: 1,
        },
        shadowOpacity: 0.16,
        shadowRadius: 1.51,
      },
      secondSubFloatingBtn: {
        bottom: hp(21),
      },
      thirdSubFloatingBtn: {
        bottom: hp(29),
      },
      fourthSubFloatingBtn: {
        bottom: hp(37),
      },
      progress: {
        width: wp(100),
        height: hp(90),
        alignSelf: 'center',
        alignItems: 'center',
        justifyContent: 'center',
      },
      noDataText: {
        textAlign: 'center',
        textAlignVertical: 'center',
        height: hp(90),
        width: wp(100),
      },
      allSelectionContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'flex-end',
        marginRight: wp(2),
      },
      allSelect: {
        marginVertical: hp(1),
      },
      selectAllText: {
        marginRight: wp(1),
      },
      placeholder: {
        color: colors.lightText,
      },
      dropDownText: {
        color: colors.text,
        fontSize: normalizeFont(12),
      },
      mainFilter: {
        width: wp(17),
        alignSelf: 'flex-end',
        right: wp(2),
      },
      icon: {
        alignSelf: 'center',
        marginVertical: hp(1),
      },
    });
  }, [wp, hp]);
  return styles;
};
