import {Dimensions, Platform} from 'react-native';
import {useResponsiveScreen} from './useResponsiveScreen';

export const {width: viewportWidth, height: viewportHeight} =
  Dimensions.get('window');
const scale = viewportWidth / 375;
export const isiPAD = viewportHeight / viewportWidth < 1.6;
export const isTablet = viewportHeight / viewportWidth < 1.6;

export function normalizeFont(size) {
  const {wp} = useResponsiveScreen();

  const newSize = size * scale;
  if (Platform.OS === 'ios') {
    if (isiPAD) {
      return Math.round(newSize) - wp(1);
    }
    return Math.round(newSize);
  }
  if (isTablet) {
    return Math.round(newSize) - wp(1);
  }
  return Math.round(newSize);
}