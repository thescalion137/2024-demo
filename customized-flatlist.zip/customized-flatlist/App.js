// import { SafeAreaView, FlatList, StyleSheet, Text, View } from "react-native";

// import React, {useState, useEffect, useRef} from 'react';
import {
  View,
  FlatList,
  Pressable,
  BackHandler,
  Animated,
  TouchableOpacity,
  Easing,
  SafeAreaView,
  Platform,
  TouchableWithoutFeedback,
  ScrollView,
  Text,
} from 'react-native';
import { StyleSheet } from 'react-native';
// import {Text} from './components/text/Text'

import React, { useState, useEffect, useRef } from 'react';

import { diamondResultStyle } from './searchDiamondResultStyle';
import { useResponsiveScreen } from './useResponsiveScreen';

const colors = {
  primary: '#024638',
  secondary: '#EFEDF2',
  dimPrimary: '#0246384d',
  dimSecondary: '#AFC9AB4d',
  danger: '#DC3545',
  text: '#555555',
  subText: '#A0A2B3',
  lightText: '#55555555',
  background: '#FFFFFF',
  drawerText: '#FFFFFF',
  headerTitle: '#1C3E71CC',
  lightBackground: '#F6F6F6',
  lightBorder: '#A0A2B333',
  midPrimary: '#02463880',
  disable: '#A0A2B340',
  black: '#000000',
  lowPrimary: '#0246381A',
  active: '#00FF00',
  loader: '#00000080',
  pending: '#fcc201',
};

const isNotRoundShape = true;

const user = {
  isKYCDone: true,
};

const DetailText = ({ title, titleDetail }) => (
  <Text numberOfLines={2} textStyle={[styles.topDetailedText]}>
    {titleDetail?.length ? titleDetail : '-'}
  </Text>
);

const data = [
  {
    awsDiamondImageLink:
      'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.istockphoto.com%2Fphoto%2Fdiamond-gm481365786-69339321&psig=AOvVaw1x_WQRD-ifHKvQw_uzcEDM&ust=1704866344255000&source=images&cd=vfe&ved=0CBIQjRxqFwoTCIC3q5jQz4MDFQAAAAAdAAAAABAE',
    barcode: '2792141',
    branch: 'Mumbai',
    certificateLink: null,
    certificateNumber: null,
    clarity: 'Vs1',
    color: 'G',
    country: 'India',
    cts: '1.440',
    culet: null,
    cut: 'Id',
    depthPercent: '61.10',
    fancyColor: null,
    fancyColorIntensity: null,
    fancyColorOvertone: null,
    fluo: 'None',
    girdle: null,
    lab: 'None',
    length: '7.26',
    lwRatio: 0,
    measurements: '7.26-7.25x4.43',
    netAmount: '296.64',
    polish: 'Ex',
    priceCT: 206,
    rapDisc: '97.49',
    rapRate: '8200.00',
    shape: 'Round',
    status: 'Available',
    stoneId: '2958371',
    symm: 'Ex',
    tablePercent: '58.50',
    width: '7.25',
  },
  {
    awsDiamondImageLink:
      'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.istockphoto.com%2Fphoto%2Fdiamond-gm481365786-69339321&psig=AOvVaw1x_WQRD-ifHKvQw_uzcEDM&ust=1704866344255000&source=images&cd=vfe&ved=0CBIQjRxqFwoTCIC3q5jQz4MDFQAAAAAdAAAAABAE',
    barcode: '2792141',
    branch: 'Mumbai',
    certificateLink: null,
    certificateNumber: null,
    clarity: 'Vs1',
    color: 'G',
    country: 'India',
    cts: '1.440',
    culet: null,
    cut: 'Id',
    depthPercent: '61.10',
    fancyColor: null,
    fancyColorIntensity: null,
    fancyColorOvertone: null,
    fluo: 'None',
    girdle: null,
    lab: 'None',
    length: '7.26',
    lwRatio: 0,
    measurements: '7.26-7.25x4.43',
    netAmount: '296.64',
    polish: 'Ex',
    priceCT: 206,
    rapDisc: '97.49',
    rapRate: '8200.00',
    shape: 'Round',
    status: 'Available',
    stoneId: '2958371',
    symm: 'Ex',
    tablePercent: '58.50',
    width: '7.25',
  },
  {
    awsDiamondImageLink:
      'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.istockphoto.com%2Fphoto%2Fdiamond-gm481365786-69339321&psig=AOvVaw1x_WQRD-ifHKvQw_uzcEDM&ust=1704866344255000&source=images&cd=vfe&ved=0CBIQjRxqFwoTCIC3q5jQz4MDFQAAAAAdAAAAABAE',
    barcode: '2792141',
    branch: 'Mumbai',
    certificateLink: null,
    certificateNumber: null,
    clarity: 'Vs1',
    color: 'G',
    country: 'India',
    cts: '1.440',
    culet: null,
    cut: 'Id',
    depthPercent: '61.10',
    fancyColor: null,
    fancyColorIntensity: null,
    fancyColorOvertone: null,
    fluo: 'None',
    girdle: null,
    lab: 'None',
    length: '7.26',
    lwRatio: 0,
    measurements: '7.26-7.25x4.43',
    netAmount: '296.64',
    polish: 'Ex',
    priceCT: 206,
    rapDisc: '97.49',
    rapRate: '8200.00',
    shape: 'Round',
    status: 'Available',
    stoneId: '2958371',
    symm: 'Ex',
    tablePercent: '58.50',
    width: '7.25',
  },
];

const FlatlistHeader = () => {
  const { wp, hp } = useResponsiveScreen();
  const styles = diamondResultStyle();

  const headerStyle = ({ index, item }) => {
    switch (item) {
      case ' ':
        return { width: wp(3) };
      case 'SH':
        if (isNotRoundShape) {
          return styles.shapeHeader;
        } else {
          return styles.shapeBigHeader;
        }

      case '$/CT':
        if (isNotRoundShape) {
          return styles.rateHeader;
        } else {
          return styles.rateBigHeader;
        }
      case 'Price':
        if (isNotRoundShape) {
          return styles.totalPriceHeader;
        } else {
          return styles.totalPriceBigHeader;
        }
      case 'CTS':
        if (isNotRoundShape) {
          return styles.caratHeader;
        } else {
          return styles.caratBigHeader;
        }

      case 'COL':
        if (isNotRoundShape) {
          return styles.colorHeader;
        } else {
          return styles.colorBigHeader;
        }

      case 'CLT':
        if (isNotRoundShape) {
          return styles.clarityHeader;
        } else {
          return styles.clarityBigHeader;
        }
      case 'CUT':
        if (isNotRoundShape) {
          return styles.cutHeader;
        } else {
          return styles.cutBigHeader;
        }
      case 'SYM':
        if (isNotRoundShape) {
          return styles.symHeader;
        } else {
          return styles.symBigHeader;
        }
      case 'RAT':
        return styles.ratioHeader;
      default:
        return null;
    }
  };

  return (
    <View style={styles.listHeader}>
      {[
        ' ',
        'SH',
        '$/CT',
        user.isKYCDone && 'Price',
        'CTS',
        'COL',
        'CLT',
        'CUT',
        'SYM',
        isNotRoundShape && 'RAT',
      ].map((item, index) => {
        console.log('-----', item);

        return (
          <Text
            key={index}
            style={[
              styles.detailedTitle1,
              headerStyle({ index, item }),
              // index === 0 && { width: wp(3) },
              // isNotRoundShape && index === 1
              //   ? { width: wp(7) }
              //   : index === 1 && { width: wp(8) },
              // isNotRoundShape && index === 2
              //   ? { width: wp(8) }
              //   : index === 2 && { width: wp(9) },
              //  user.isKYCDone ? isNotRoundShape && index === 3
              //   ? { width: wp(11) }
              //   : index === 3 && { width: wp(12) } : wp(0),
              // isNotRoundShape && index === (user.isKYCDone ? 4 : 3)
              //   ? { width: wp(11) }
              //   : index === (user.isKYCDone ? 4 : 3) && { width: wp(12) },
              // isNotRoundShape && index === (user.isKYCDone ? 5 : 4)
              //   ? { width: wp(8) }
              //   : index === (user.isKYCDone ? 5 : 4) && { width: wp(9) },
              // isNotRoundShape && index === (user.isKYCDone ? 6 : 5)
              //   ? { width: wp(9) }
              //   : index === (user.isKYCDone ? 6 : 5) && { width: wp(10) },
              // isNotRoundShape && index === (user.isKYCDone ? 7 : 6)
              //   ? { width: wp(10) }
              //   : index === (user.isKYCDone ? 7 : 5) && { width: wp(11) },
              // // isNotRoundShape && index === 7
              // //   ? {width: wp(8)}
              // //   : index === 7 && {width: wp(9)},
              // isNotRoundShape && index === (user.isKYCDone ? 8 :7)
              //   ? { width: wp(9) }
              //   : index === (user.isKYCDone ? 8 :7) && { width: wp(10) },
              // isNotRoundShape && index === (user.isKYCDone ? 9 : 8) && { width: wp(8) },
            ]}>
            {item}
          </Text>
        );
      })}
    </View>
  );
};

const RenderItem = ({
  item,
  itemIsSelected,
  setIsSelection,
  onSelect,
  navigation,
  totalPrice,
  isSelection,
  favIncluded,
  onSetFavourite,
  rate,
  DetailText,
  styles,
  dispatch,
  theme,
  wp,
}) => {
  const [expandedData, setExpandedData] = useState(false);

  const getShape = (str) => {
    if (str.length) {
      const arr = str.split(' ');
      if (arr.length === 1) {
        return str.slice(0, 2);
      } else if (arr.length > 1) {
        var matches = str.match(/\b(\w)/g);
        return matches.join('');
      }
    } else {
      return '-';
    }
  };

  const getModifiedText = (titleText) => (titleText?.length ? titleText : '-');

  return (
    <>
      <View
        style={[
          styles.cardView,
          // isSelection && itemIsSelected && styles.selectedItem,
        ]}>
        <Pressable
          style={styles.pressableCardContainer}
          // onLongPress={() => {
          //   if (item?.status === 'Available') {
          //     setIsSelection(true);
          //     onSelect(item);
          //   }
          // }}
          delayLongPress={700}
          // onPress={() => {
          //   dispatch(setDiamondDetail(item));
          //   navigation.navigate(SCREEN.diamondView);
          // }}
        >
          <View style={styles.availableContainer}>
            <View
              style={[
                styles.available,
                item?.status === 'Available'
                  ? styles.availableColor
                  : styles.unAvailableColor,
              ]}
            />
          </View>
          <View style={styles.detailsContainer}>
            <View style={styles.detailsData}>
              <View style={styles.listColumn}>
                <Text
                  style={[
                    isNotRoundShape ? styles.shapeText : styles.shapeBigText,
                  ]}>
                  {getShape(item?.shape)}
                </Text>
                <Text
                  style={[
                    isNotRoundShape ? styles.rateText : styles.rateBigText,
                  ]}>
                  {/* {rate.length ? `$${rate}` : '-'} */}
                  {item?.priceCT ? Math.round(parseFloat(item.priceCT)) : '-'}
                </Text>
                {user.isKYCDone && (
                  <Text
                    style={[
                      isNotRoundShape
                        ? styles.totalPriceText
                        : styles.totalPriceBigText,
                    ]}>
                    {totalPrice.length
                      ? `$${Math.round(
                          parseFloat(totalPrice)
                        )?.toLocaleString()}`
                      : '-'}
                  </Text>
                )}
                <Text
                  style={[
                    isNotRoundShape ? styles.caratText : styles.caratBigText,
                  ]}>
                  {getModifiedText(item?.cts)}
                </Text>
                <Text
                  style={[
                    isNotRoundShape ? styles.colorText : styles.colorBigText,
                  ]}>
                  {getModifiedText(item?.color)}
                </Text>
                <Text
                  style={[
                    isNotRoundShape
                      ? styles.clarityText
                      : styles.clarityBigText,
                  ]}>
                  {getModifiedText(item?.clarity?.toUpperCase())}
                </Text>
                <Text
                  style={[
                    isNotRoundShape ? styles.cutText : styles.cutBigText,
                  ]}>
                  {getModifiedText(item.cut)}
                </Text>
                {/* <Text
                  textStyle={[
                    isNotRoundShape ? styles.discText : styles.discBigText,
                  ]}>
                  {item?.rapDisc ? `-${parseInt(+item.rapDisc)}` : '-'}
                </Text> */}
                <Text
                  style={[
                    isNotRoundShape ? styles.symText : styles.symBigText,
                  ]}>
                  {getModifiedText(item?.symm?.toUpperCase())}
                </Text>
                {isNotRoundShape && (
                  <Text style={[styles.ratioText]}>
                    {getModifiedText(item?.lwRatio?.toFixed(2)?.toString())}
                  </Text>
                )}
              </View>
            </View>
          </View>
        </Pressable>
        <View style={[styles.checkboxContainer]}>
          {false ? (
            <Checkbox
              value={itemIsSelected}
              onValueChange={() => {
                // if (item?.status === 'Available') {
                //   onSelect(item);
                // }
              }}
              disabled={item?.status !== 'Available' && true}
              uncheckedBorder={theme?.primary}
              checkedBorder={theme?.primary}
            />
          ) : (
            <></>
            // <Pressable onPress={() => {}}>
            //   {favIncluded ? (
            //     <Svg.HeartIcon height={wp(5)} width={wp(5)} />
            //   ) : (
            //     <Svg.BorderHeartIcon height={wp(5)} width={wp(5)} />
            //   )}
            // </Pressable>
          )}
        </View>
        <View style={[styles.checkboxContainer]}>
          <Pressable
            style={styles.icon}
            // onPress={() => {
            //   if (!expandedData) {
            //     dispatch(setDiamondDetail(item));
            //   }
            //   setExpandedData(!expandedData);
            // }}
          ></Pressable>
        </View>
      </View>
    </>
  );
};

export default function App() {
  const styles = diamondResultStyle();
  const { wp, hp } = useResponsiveScreen();

  const priceFormat = (price) => {
    return price.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  };

  const renderItems = ({ item }) => {
    const netRapRate = item?.priceCT?.toFixed(0);
    const totalPrice = priceFormat((netRapRate * item?.cts).toFixed(2));
    const rate = priceFormat(netRapRate);
    const favIncluded = 1;
    const itemIsSelected = 1;

    return (
      <>
        <RenderItem
          item={item}
          itemIsSelected={itemIsSelected}
          // setIsSelection={setIsSelection}
          // onSelect={onSelect}
          // navigation={navigation}
          totalPrice={totalPrice}
          // isSelection={isSelection}
          favIncluded={favIncluded}
          // onSetFavourite={onSetFavourite}
          rate={rate}
          DetailText={DetailText}
          styles={styles}
          // dispatch={dispatch}
          // theme={theme}
          wp={wp}
        />
      </>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <FlatList
        ListHeaderComponent={FlatlistHeader}
        data={data}
        renderItem={renderItems}
        stickyHeaderIndices={[0]}
        keyExtractor={(item, index) => index.toString()}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.cardContentContainer}
        // onScroll={handleDropdown}
      />
    </SafeAreaView>
  );
}

//styles to see the data more clearly

const styles = StyleSheet.create({
  container: {
    padding: 50,
    flex: 1,
  },
  item: {
    padding: 20,
    fontSize: 15,
    marginTop: 5,
  },
});
