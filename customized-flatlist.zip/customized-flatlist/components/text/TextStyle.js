import {useMemo} from 'react';
import {StyleSheet} from 'react-native';
import {normalizeFont} from '../../normalize';

export const textStyle = () => {
  const styles = useMemo(() => {
    return StyleSheet.create({
      normalText: {
        fontSize: normalizeFont(14),
      },
    });
  }, []);
  return styles;
};

