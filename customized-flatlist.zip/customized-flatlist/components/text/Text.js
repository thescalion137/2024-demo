import React, {useContext} from 'react';
import {Text as RNText} from 'react-native';
import {textStyle as textStyles} from './TextStyle';

const Text = ({textStyle, align, color, children, ...props}) => {
  const styles = textStyles();
 
  return (
    <RNText
      style={[
        styles.normalText,
        {textAlign: align, color: color ? color : '#024638'},
        // customFonts.regular,
        textStyle,
      ]}
      {...props}>
      {children}
    </RNText>
  );
};

export default Text;