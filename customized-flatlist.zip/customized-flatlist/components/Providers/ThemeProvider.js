import React, {createContext, useState} from 'react';
import {StatusBar} from 'react-native';
import {themeColors} from '../Styles/themeColors';

export const ThemeContext = createContext();

export const ThemeProvider = ({children}) => {
  const [themeMode, setThemeMode] = useState('light');
  const [theme, setTheme] = useState(themeColors.light);

  const handleTheme = () => {
    if (themeMode === 'light') {
      setThemeMode('dark');
      setTheme(themeColors.dark);
      StatusBar.setBarStyle('light-content', true);
    } else {
      setThemeMode('light');
      setTheme(themeColors.light);
      StatusBar.setBarStyle('dark-content', true);
    }
  };

  return (
    <ThemeContext.Provider value={{theme, handleTheme}}>
      {children}
    </ThemeContext.Provider>
  );
};