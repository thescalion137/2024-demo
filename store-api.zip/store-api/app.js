import dotenv from "dotenv";
import express from "express";
import notFound from "./src/middleware/not-found.js";
import errorHandlerMiddleware from "./src/middleware/error-handler.js";
import connectDatabase from "./src/db/connect.js";
import router from "./src/routes/products.js";
import "express-async-errors";

// ENV configuration
dotenv.config();

//middleware
const app = express();
app.use(express.json());

//Routes
app.get("/", (req, res) => {
  res.send(
    '<h1>Store API</h1><br/><a href="/api/v1/products">Products Route</a>'
  );
});

app.use("/api/v1/products", router);

// Product Routes
app.use(notFound);
app.use(errorHandlerMiddleware);

// Server setup
const port = process.env.PORT || 3000;
const dbUrl = process.env.MONGO_URI;

const start = async () => {
  try {
    //connectDB
    await connectDatabase(dbUrl);
    app.listen(port, console.log("server is listening on port : ", port));
  } catch (error) {
    console.log("🚀 ~ start ~ error:", error);
  }
};

start();
