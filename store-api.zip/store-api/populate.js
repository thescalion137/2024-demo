import dotenv from "dotenv";
import express from "express";
import connectDatabase from "./src/db/connect.js";
import Product from "./src/models/product.js";
import { productData } from "./product.js";

// ENV configuration
dotenv.config();
// Server setup
const port = process.env.PORT || 3000;
const dbUrl = process.env.MONGO_URI;

//middleware
const app = express();
app.use(express.json());

const start = async () => {
  try {
    await connectDatabase(dbUrl);
    await Product.deleteMany();
    await Product.create(productData);
    console.log("static data added successfully in database");
    process.exit(0);
  } catch (error) {
    console.log("🚀 ~ start ~ error:", error);
    process.exit(1);
  }
};

start();
