import Product from "../models/product.js";

export const getAllProductsStatic = async (req, res) => {
  const products = await Product.find({});
  res.status(200).json({
    message: "Product fetched successfully",
    data: products,
    nbHits: products.length,
  });
};

export const getAllProducts = async (req, res) => {
  const { featured, company, name, sort, fields, page, limit, numericFilters } =
    req.query;
  const queryObject = {};

  if (featured) {
    queryObject.featured = featured === "true" ? true : false;
  }
  if (company) {
    queryObject.company = company;
  }
  if (name) {
    queryObject.name = { $regex: name, $options: "i" };
  }
  //Numeric Filters
  if (numericFilters) {
    const operatorMap = {
      ">": "$gt",
      ">=": "$gte",
      "=": "$eq",
      "<": "$lt",
      ">=": "$lte",
    };

    const regEx = /\b(<|>|>=|=|<|<=)\b/g;
    let filters = numericFilters.replace(
      regEx,
      (match) => `-${operatorMap[match]}-`
    );
    const options = ["price", "rating"];
    filters = filters.split(",").forEach((element) => {
      const [field, operator, value] = element.split("-");
      if (options.includes(field)) {
        queryObject[field] = { [operator]: Number(value) };
      }
    });
  }

  let result = Product.find(queryObject);
  //sorting
  if (sort) {
    const sortList = sort.split(",").join(" ");
    result = result.sort(sortList);
  } else {
    result = result.sort("createdAt");
  }

  //Fields
  if (fields) {
    const fieldsList = fields.split(",").join(" ");
    result = result.select(fieldsList);
  }

  if (limit) {
    result = result.limit(limit);
  }

  // Pagination
  const pageNumber = Number(page) || 1;
  const pageLimit = Number(limit) || 10;
  const skip = (pageNumber - 1) * pageLimit;

  result = result.skip(skip).limit(pageLimit);

  const products = await result;
  res.status(200).json({
    message: "Product fetched successfully",
    data: products,
    nbHits: products.length,
  });
};
