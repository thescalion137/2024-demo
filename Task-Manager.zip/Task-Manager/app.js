import dotenv from "dotenv";
// ENV configuration
dotenv.config();

import express from "express";
import router from "./src/routes/tasks.js";
import connectDatabase from "./src/db/connect.js";
import notFound from "./src/middleware/not-found.js";
import errorHandlerMiddleware from "./src/middleware/error-handler.js";
const app = express();

// middleware
app.use(express.json());

// -- Routes
app.use("/api/v1/tasks", router);
app.use(notFound);
app.use(errorHandlerMiddleware);

const port = process.env.PORT || 3000;

const startDatabase = async () => {
  try {
    await connectDatabase(process.env.MONGO_URL);
    app.listen(port, () => {
      console.log("listening on port", port);
    });
  } catch (error) {
    console.log("🚀 ~ startDatabase ~ error:", error);
  }
};

//connect database
startDatabase();
