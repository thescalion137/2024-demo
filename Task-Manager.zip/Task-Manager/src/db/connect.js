import mongoose from "mongoose";

const connectDatabase = async (url) => {
  try {
    await mongoose.connect(url);
    console.log("database connection established");
  } catch (error) {
    console.log("database connection error: ", error);
  }
};
export default connectDatabase;
