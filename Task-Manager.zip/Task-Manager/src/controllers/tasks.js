import createCustomError from "../errors/custom-error.js";
import asyncWrapper from "../middleware/async.js";
import Task from "../models/Task.js";

export const getAllTasks = asyncWrapper(async (req, res) => {
  const task = await Task.find({});
  res.status(200).json({ data: task, message: "Task fetched successfully" });
});

export const createTask = asyncWrapper(async (req, res) => {
  const task = await Task.create(req.body);
  res.status(201).json({ data: task, message: "Task created successfully" });
});

export const getTask = asyncWrapper(async (req, res, next) => {
  const { id: taskID } = req.params;
  const task = await Task.findOne({ _id: taskID });

  if (!task) {
    return next(createCustomError(`No task found with id : ${taskID}`, 404));
    // const error = new Error("Not Found");
    // error.status = 404;
    // error.message = "Task not found";
    // return next(error);

    // return res
    //   .status(404)
    //   .json({ message: `No task found with id : ${taskID}` });
  }

  res.status(200).json({ data: task, message: "Task fetched successfully" });
});

export const updateTask = asyncWrapper(async (req, res) => {
  const { id: taskID } = req.params;
  const taskData = req.body;

  const task = await Task.findOneAndUpdate({ _id: taskID }, taskData, {
    new: true,
    runValidators: true,
  });

  if (!task) {
    return next(createCustomError(`No task found with id : ${taskID}`, 404));
  }

  res.status(200).json({ data: task, message: "Task updated successfully" });
});

export const deleteTask = asyncWrapper(async (req, res) => {
  const { id: taskID } = req.params;

  const task = await Task.findOneAndDelete({ _id: taskID });
  if (!task) {
    return next(createCustomError(`No task found with id : ${taskID}`, 404));
  }
  res.status(200).json({ data: task, message: "Task deleted successfully" });
});
