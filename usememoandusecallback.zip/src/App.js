import logo from "./logo.svg";
import "./App.css";
import { useCallback, useState } from "react";
import Counter from "./Components/Counter";
import ParentComp from "./Components/Callback/ParentComp";

function App() {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <ParentComp />
      {/* <Counter /> */}
    </div>
  );
}

export default App;
