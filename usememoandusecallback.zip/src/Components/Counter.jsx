import React, { useMemo, useState } from "react";

const Counter = () => {
  const [counterOne, setCounterOne] = useState(0);
  const [counterTwo, setCounterTwo] = useState(0);

  const handleChangeCounterOne = () => {
    setCounterOne(counterOne + 1);
  };

  const handleChangeCounterTwo = () => {
    setCounterTwo(counterTwo + 1);
  };

  const isEven = useMemo(() => {
    let i = 0;
    while (i < 2000000000) i++;
    return counterOne % 2 === 0;
  }, [counterOne]);

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      <button onClick={handleChangeCounterOne}>
        counterOne : {counterOne}
      </button>
      {isEven ? "Even" : "odd"}
      <button onClick={handleChangeCounterTwo}>
        counterTwo : {counterTwo}
      </button>
    </div>
  );
};

export default Counter;
