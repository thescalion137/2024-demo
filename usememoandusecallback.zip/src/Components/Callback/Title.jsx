import React from "react";

const Title = () => {
  console.log("rendered title component");
  return <div>useCallback Hook</div>;
};

export default React.memo(Title);
