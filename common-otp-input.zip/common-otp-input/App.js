import OTPInput from './components/OTPInput.jsx'


export default function App() {
   const handleSubmit = (pin: string) => {
        // handle api request here but I'm console logging it
        console.log(pin)
    }
  return (
         <OTPInput length={6} onComplete={handleSubmit} />

  );
}


